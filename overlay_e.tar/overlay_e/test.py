def HTMLColorToRGB(colorstring):
    """ convert #RRGGBB to an (R, G, B) tuple """
    colorstring = colorstring.strip()
    if colorstring[0] == '#': colorstring = colorstring[1:]
    if len(colorstring) != 6:
        raise ValueError, "input #%s is not in #RRGGBB format" % colorstring
    r, g, b = colorstring[:2], colorstring[2:4], colorstring[4:]
    r, g, b = [int(n, 16) for n in (r, g, b)]
    return (r, g, b)
def colors(n):
    """Compute a list of distinct colors, each of which is represented as an RGB 3-tuple."""
    """It's useful for less than 100 numbers"""
    if pow(n,float(1)/3)%1==0.0:
        n+=1 
	  #make sure number we get is more than we need.
    rgbcolors=[]
    x=pow(n,float(1)/3)
    a=int(x)
    b=int(x)
    c=int(x)
    if a*b*c<=n:
       a+=1
    if a*b*c<n:
       b+=1
    if a*b*c<n:
       c+=1
    for i in range(a):
       r=254/(a)*(i)
       for j in range(b):
          s=254/(b)*(j)
          for k in range(c):
             t=254/(c)*(k)
             color=r,s,t
             rgbcolors.append(color)
    hexcolor=[]
    for i in a:
        hexcolor.append('#%02x%02x%02x' % i)         
    return hexcolor
class MyClass:
    """A simple example class"""
    i = 12345
    def f(self):
        return 'hello world'



a=colors(10)
hexcolor=[]
for i in a:
    hexcolor.append('#%02x%02x%02x' % i)
print hexcolor